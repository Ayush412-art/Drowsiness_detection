# Driver drowsiness detection > 2025-04-12 8:18pm
https://universe.roboflow.com/adityas-workspace-0qfpw/driver-drowsiness-detection-gk0ws-orgoc

Provided by a Roboflow user
License: CC BY 4.0

